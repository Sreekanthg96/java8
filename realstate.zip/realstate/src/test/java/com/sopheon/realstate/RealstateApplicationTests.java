package com.sopheon.realstate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealstateApplicationTests {

	@Test
	void contextLoads() {
	}

}
